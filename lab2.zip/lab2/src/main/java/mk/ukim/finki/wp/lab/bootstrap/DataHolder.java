package mk.ukim.finki.wp.lab.bootstrap;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class DataHolder {

    private final AuthorRepository authorRepository;
    private final BookRepository bookRepository;

    public DataHolder(AuthorRepository authorRepository, BookRepository bookRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void init() {

        // Authors are already added in AuthorRepository constructor
        Author orwell = authorRepository.findById(1L);
        Author camus = authorRepository.findById(2L);
        Author rowling = authorRepository.findById(3L);

        // Add books
        bookRepository.save("1984", "Dystopia", 4.5, orwell);
        bookRepository.save("Animal Farm", "Political Satire", 4.3, orwell);
        bookRepository.save("The Stranger", "Philosophy", 4.2, camus);
        bookRepository.save("Harry Potter and the Philosopher's Stone", "Fantasy", 4.8, rowling);
        bookRepository.save("Harry Potter and the Chamber of Secrets", "Fantasy", 4.7, rowling);
    }
}
