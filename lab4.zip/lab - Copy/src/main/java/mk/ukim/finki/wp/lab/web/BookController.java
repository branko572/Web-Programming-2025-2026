package mk.ukim.finki.wp.lab.web;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.AuthorService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;
    private final AuthorService authorService;

    public BookController(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }

    @GetMapping
    public String listBooks(Model model) {
        model.addAttribute("books", bookService.listAll());
        return "listBooks";
    }

    @GetMapping("/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("authors", authorService.listAll());
        model.addAttribute("book", new Book());
        return "book-form";
    }

    @PostMapping("/add")
    public String saveBook(@ModelAttribute Book book, @RequestParam Long authorId) {
        Author author = authorService.listAll().stream()
                .filter(a -> a.getId().equals(authorId))
                .findFirst()
                .orElseThrow();
        book.setAuthor(author);
        bookService.save(book);
        return "redirect:/books";
    }

    @GetMapping("/edit/{id}")
    public String showEditBookForm(@PathVariable Long id, Model model) {
        Book book = bookService.listAll().stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow();
        model.addAttribute("book", book);
        model.addAttribute("authors", authorService.listAll());
        return "book-form";
    }

    @PostMapping("/edit/{id}")
    public String updateBook(@PathVariable Long id, @ModelAttribute Book book, @RequestParam Long authorId) {
        Author author = authorService.listAll().stream()
                .filter(a -> a.getId().equals(authorId))
                .findFirst()
                .orElseThrow();
        book.setAuthor(author);
        book.setId(id);
        bookService.save(book);
        return "redirect:/books";
    }

    @PostMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        bookService.deleteById(id);
        return "redirect:/books";
    }
}
