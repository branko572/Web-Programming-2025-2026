package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class InMemoryBookReservationRepository implements BookReservationRepository {

    private final List<BookReservation> reservations = new ArrayList<>();

    @Override
    public BookReservation save(BookReservation reservation) {
        reservations.add(reservation); // add new reservation
        return reservation;
    }

    public List<BookReservation> findAll() {
        return reservations;
    }
}
