package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.Author;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class InMemoryBookRepository implements BookRepository {

    private final List<Book> books = new ArrayList<>();
    private Long nextId = 1L;

    @Override
    public List<Book> findAll() { return books; }

    @Override
    public Book findById(Long id) {
        return books.stream().filter(b -> b.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(String title, String genre, Double averageRating, Author author) {
        books.add(new Book(nextId++, title, genre, averageRating, author));
    }

    @Override
    public void update(Long id, String title, String genre, Double averageRating, Author author) {
        Book book = findById(id);
        if (book != null) {
            book.setTitle(title);
            book.setGenre(genre);
            book.setAverageRating(averageRating);
            book.setAuthor(author);
        }
    }

    @Override
    public void deleteById(Long id) {
        books.removeIf(b -> b.getId().equals(id));
    }
}
