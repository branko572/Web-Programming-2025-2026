package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {

    public static List<BookReservation> reservations = new ArrayList<>();

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public DataHolder(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @PostConstruct
    public void init() {
        Author duneAuthor = authorRepository.save(new Author("Frank Herbert"));
        Author orwellAuthor = authorRepository.save(new Author("George Orwell"));
        Author tolkienAuthor = authorRepository.save(new Author("J.R.R. Tolkien"));

        bookRepository.save(new Book("Dune", "Sci-Fi", 9.5, duneAuthor));
        bookRepository.save(new Book("1984", "Dystopian", 9.0, orwellAuthor));
        bookRepository.save(new Book("The Hobbit", "Fantasy", 8.8, tolkienAuthor));
    }
}
