package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {

    public static List<Book> books = new ArrayList<>();
    public static List<BookReservation> reservations = new ArrayList<>();

    @PostConstruct
    public void init() {
        books.add(new Book("Dune", "Sci-Fi", 9.5));
        books.add(new Book("1984", "Dystopian", 9.0));
        books.add(new Book("The Hobbit", "Fantasy", 8.8));
        books.add(new Book("The Catcher in the Rye", "Classic", 8.0));
        books.add(new Book("The Shining", "Horror", 8.7));
        books.add(new Book("Brave New World", "Sci-Fi", 8.3));
        books.add(new Book("Moby Dick", "Adventure", 7.9));
        books.add(new Book("It", "Horror", 8.5));
        books.add(new Book("To Kill a Mockingbird", "Classic", 9.2));
        books.add(new Book("Neuromancer", "Cyberpunk", 8.6));
    }
}
