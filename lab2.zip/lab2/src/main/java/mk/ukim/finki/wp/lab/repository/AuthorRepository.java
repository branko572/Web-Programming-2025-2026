package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Author;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Repository // <-- This makes it a Spring Bean
public class AuthorRepository {
    private final List<Author> authors = new ArrayList<>();

    public AuthorRepository() {
        authors.add(new Author(1L,"George", "Orwell", "UK","Famous for '1984' and 'Animal Farm'"));
        authors.add(new Author(2L,"Albert", "Camus", "France", "Famous for 'The Stranger' and 'The Myth of Sisyphus'"));
        authors.add(new Author(3L, "J.K", "Rowling", "UK", "Author of the Harry Potter series"));
    }

    public List<Author> findAll() {
        return authors;
    }

    public Author findById(Long id) {
        return authors.stream().filter(a -> a.getId().equals(id)).findFirst().orElse(null);
    }
}
