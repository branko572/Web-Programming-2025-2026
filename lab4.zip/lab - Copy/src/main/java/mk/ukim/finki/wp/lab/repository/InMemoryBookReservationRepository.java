package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Repository;

@Repository
public class InMemoryBookReservationRepository implements BookReservationRepository {

    @Override
    public BookReservation save(BookReservation reservation) {

        // remove previous reservation for same book title
        DataHolder.reservations.removeIf(
                r -> r.getBookTitle().equals(reservation.getBookTitle())
        );

        // add new reservation
        DataHolder.reservations.add(reservation);

        return reservation;
    }
}
