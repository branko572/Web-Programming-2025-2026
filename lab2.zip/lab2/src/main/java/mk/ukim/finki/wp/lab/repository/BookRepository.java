package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.Author;

import java.util.List;

public interface BookRepository {
    List<Book> findAll();
    Book findById(Long id);
    void save(String title, String genre, Double averageRating, Author author);
    void update(Long id, String title, String genre, Double averageRating, Author author);
    void deleteById(Long id);
}
