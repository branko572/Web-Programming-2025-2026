package mk.ukim.finki.wp.lab.web.controller;

import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/reservation")
public class BookReservationController {

    private final BookService bookService;

    public BookReservationController(BookService bookService) {
        this.bookService = bookService;
    }

    @PostMapping("/create")
    public String createReservation(@RequestParam Long bookId,
                                    @RequestParam Integer copies,
                                    @RequestParam String name,
                                    @RequestParam String address,
                                    HttpServletRequest request,
                                    Model model) {
        Book book = bookService.findById(bookId);
        if (book == null) {
            return "redirect:/books?error=BookNotFound";
        }

        String clientIp = request.getRemoteAddr();

        // Во in-memory пример: може да имаш ReservationService; овде само прикажуваме confirmation
        model.addAttribute("book", book);
        model.addAttribute("copies", copies);
        model.addAttribute("name", name);
        model.addAttribute("address", address);
        model.addAttribute("clientIp", clientIp);

        return "reservationConfirmation";
    }

    // Опционално: покажи форма за резервација (ако користиш посебна)
    @GetMapping("/form")
    public String showReservationForm(Model model) {
        model.addAttribute("books", bookService.findAll());
        return "reservation-form";
    }
}
